# Scripts Directory
This directory will contain SQL Migration Scripts